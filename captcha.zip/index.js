function keysubmit(a)
{return 13!=a.keyCode||void document.getElementById("frm").submit()}

