<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<style>

</style>
</head>
<body>
<?php 
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
function redirect($url)
{
    
    if (!headers_sent()){
        header("Location: $url");
    }else{
       echo "<script type='text/javascript'>
        window.location.href='$url'
        exit();
        </script>";
        echo "<noscript><meta  http-equiv='refresh' content='0;url='$url'/></noscript>";
    }
    exit;
}

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    require 'config.php';
    
    $email_user=test_input($_POST['user_emial_login']);
    $pass=test_input($_POST['pass_login']);

    $sql = "SELECT * FROM UserLogsInfo WHERE password=$pass AND (username='$email_user' OR email='$email_user')";
    $result = $conn->query($sql);
     if($result->num_rows > 0)
     {
         $_SESSION['email']=$row['email']; //logout
         $url="http://www.mehrdadweb.ir/user/userpanel.php?id=$email_user";
         redirect($url); 
      
     }
     else
     {
      echo '<a href="http://www.mehrdadweb.ir">Go back and Enter Correct username & password</a>';
     }
     exit();
    }

?>

</body>
</html>