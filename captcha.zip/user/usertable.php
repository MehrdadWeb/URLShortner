<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<!--<html lang="en">  English -->
<html dir="rtl" lang="fa">
<head>
<style>

</style>
    <meta name="author" content="Mehrdad Mohammadi" />
    <title>Mehrdad Mohammadi</title>
    <link rel="stylesheet" href="/user/userpanel.css">
    <meta charset="UTF-8" />
    <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="jquery-3.4.1.min.js"></script>
    <script type="application/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script>

        function sendForm(){
            $.ajax({
                type: "POST",
                url: "https://mehrdadweb.ir/shortlink/shortlink.php",
                data: jQuery("#my_form").serialize(),
                cache: false,
                success:  function(data){
                    /* alert(data); if json obj. alert(JSON.stringify(data));*/
                }
            });

        }
        /*
        function submit(str) {
	    if (str == "") {
	        document.getElementById("txtHint").innerHTML = "";
            return;
	        
	    }else { 
	        var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
                
            }
                
            };
            xmlhttp.open("GET","https://www.mehrdadweb.ir/dologin.php?q=?p="+str1?str2,true);
            xmlhttp.send();
	    
	    }
	    
	}*/

    </script>
 
   
</head>

<body>

<header>
    <div><img src="/images/header2.png" class="heaerimg" alt="guitarimage"></div>
    
    <div class="headerslider-text">
        <h1>مهرداد محمدی</h1>
    </div>
    

</header>

<nav>

    <a class="nav-link" href="https://mehrdadweb.ir">صفحه اصلی</a>
    <a class="nav-link" href="/shortlink/shortlinker.html" target="_blank">
        "پروژه ها"
        <!--<div class="nav-link-hover">
            <ul>
            <li>پروژه کوتاه کردن لینک</li>
            <li>پروژه 2</li>
            <li>پروژه 3</li>
            <li>پروژه 4</li>
            </ul>
        </div>-->

    </a>
    <a class="nav-link" href="/kiana/kiana.html" target="_blank">کیانا</a>
    <a class="nav-link">بنیاد</a>
    <a class="nav-link">دنیا</a>

</nav>

<main class="mainslider">

    <div class="article">


        <pre> کاربر گرامی </pre> <span style="color:red;"><?php echo $_GET['id'];?></span> <pre> جدول خود را در زیر مشاهده می کنید </pre>
        <?php $user_name=$_GET['id']; ?>

        <br><br>
        <div class="table">
        <?php
require 'config.php';        
$sql = "SELECT * FROM UserLinks WHERE username='$user_name'";
$result = $conn->query($sql);
    if ($result->num_rows > 0){
        echo "<table>
<tr>
<th>ID</th>
<th>Usename</th>
<th>Link</th>
<th>Shortlink</th>

</tr>";
        while($row = ($result->fetch_assoc()))
        {
        
          
          echo "<tr>";
          echo "<td>". $row['id'] . "</td>";
          echo "<td>" . $row['username'] . "</td>";
          echo "<td>" . $row['link'] . "</td>";
          echo "<td>" . $row['shortlink'] . "</td>";
          echo "<td>" . $row['datetime'] . "</td>";
          echo "</tr>";
        
                
        

        
    }
    echo "</table>";
    }
    $conn->close();
    
?>
</div>
    </div>

    <aside class="aside">
        <ul>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </aside>

</main>

<footer>
    <pre class="footer-text">
        تماس با ما
        Mobile No: 09353408373
        Gmail:      mehrdadmmg2012@gmail.com
        Telegram:  mehrdad_mg91
        instagram: mehrdad.mohammadi7
    </pre> 

</footer>
<script language="javascript" type="text/javascript" src="index.js"></script>
</body>
</html>