<!DOCTYPE html>
<html>
<head>
</head>
<body>
    
<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // collect value of input field
    $link = $_POST['longlink'];
    if (empty($link)) {
        echo "Link is empty , Please insert yor link";
        exit();
    }
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    $resultmix = '';
    for ($i = 0; $i < 5; $i++){
        $resultmix .= $characters[mt_rand(0, 61)];}
        $baseurl = "mehrdadweb.ir/";
        $shortl=$baseurl;
        $shortl.=$resultmix;
        
        $sql = "INSERT INTO LINKSTABLE(link, shortlink) VALUES ('$link','$shortl')";
        if ($conn->query($sql) === TRUE) {
 
        }
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
            
             }
////////////////////////////////////////////////////////////////////////////////////////////////////             
        if($_GET['id'])
        {
            $hello="Welcome Dear user  : ";
            $user_name=$_GET['id'];
            $sql_user_insert="INSERT INTO UserLinks(username, link, shortlink) VALUES ('$user_name','$link','$shortl')";  
            if ($conn->query($sql_user_insert) === TRUE) {
 
            }
             else {
            echo "Error: " . $sql_user_insert . "<br>" . $conn->error;
            
             }
        }     
////////////////////////////////////////////////////////////////////////////////////////////////////        
        $conn->close();     
        
}
?>

<form >
    <pre>Your short link is (copy the short link in search bar and go) :  </pre> 
    <tr><td> <input type="text" name="id"  value="<?php echo $shortl;?>"> </td></tr> 
    <br>
    <br>
    <pre><span style="color:red;"><?php echo $hello.$user_name;?></span></pre>
    <br>
    <button class="copy-link" id="copy-link" name="copy-link">Copy</button>
    
</form>
</body>
</html>

